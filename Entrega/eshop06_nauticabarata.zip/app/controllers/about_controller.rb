class AboutController < ApplicationController
  def index
    @page_title = '¿Quiénes somos?'
  end
end
