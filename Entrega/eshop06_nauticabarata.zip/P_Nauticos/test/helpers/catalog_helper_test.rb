require 'test_helper'

class CatalogHelperTest < ActionView::TestCase
end
