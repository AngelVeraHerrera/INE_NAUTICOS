require 'test_helper'

class Admin::ProductHelperTest < ActionView::TestCase
end
